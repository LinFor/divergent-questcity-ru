
<?php
$language = "ru_RU.php";
$org_name = "Ваша организация";
$org_description = "Онлайн бронирование";
$org_phone = "+79997779977";
$org_mail = "admin@onriv.com";
$sent_mail = "1";
$sent_in_org_mail = "1";
$sent_mail_status = "1";
$confirm_mail = "1";
$currency_name = "RUB::USD::EUR::UAH::GPB::";
$currency_simbol = '<i class="icon-rouble"></i>::<i class="icon-dollar"></i>::<i class="icon-euro"></i>::₴::<i class="icon-pound"></i>::';
$currency_position = "r::l::l::r::l::";
$conf_form = "0";
$captcha = "1";
$color1 = "#FC8F1A";
$color2 = "#FF4D00";
$custom_css = ".my_footer {margin:14px 0 0 0; padding:0; width:100%; background:#101321;}
.my_copy {text-align:right; padding:56px 14px; color:#fff;}
.my_copy span {color:#FC8F1A;}";
$custom_header = "";
$custom_footer = "&lt;div class=:kv2:my_footer:kv2:&gt;
  &lt;div class=:kv2:my_copy:kv2:&gt;&lt;span&gt;Ваша&lt;/span&gt; организация &amp;copy; 2016&lt;/div&gt;
&lt;/div&gt;";
?>
