
<?php
$paypal_active = "1";
$paypal_mail = "admin@onriv.com";
$paypal_sendbox = "0";
?>
