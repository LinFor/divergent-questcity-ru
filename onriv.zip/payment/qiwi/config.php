
<?php
$qiwi_active = "1";
$qiwi_from = "12345";
?>
