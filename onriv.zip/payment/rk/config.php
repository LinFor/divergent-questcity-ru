
<?php
$rk_active = "1";
$rk_login = "OnRiv";
$rk_pass = "12345";
?>
