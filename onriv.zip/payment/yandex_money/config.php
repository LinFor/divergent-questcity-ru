
<?php
$yandex_money_active = "1";
$yandex_money_receiver = "1234567890";
?>
